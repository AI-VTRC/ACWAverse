const fs = require('fs');
const vm = require('vm');
const assert = require('assert');

function loadEngine() {
  const context = { console, window: {} };
  vm.createContext(context);
  const engineCode = fs.readFileSync(__dirname + '/../acwa-engine.js', 'utf8');
  vm.runInContext(engineCode, context, { filename: 'acwa-engine.js' });
  return context.window.ACWAEngine;
}

function approxEqual(a, b, eps = 1e-9) { return Math.abs(a - b) <= eps; }

async function main() {
  const E = loadEngine();
  let failed = 0;
  let passed = 0;
  function test(name, fn){
    try { fn(); console.log('PASS', name); passed++; }
    catch (e) { console.error('FAIL', name, e.stack || e); failed++; }
  }

  test('isValveOpen logic', () => {
    assert.strictEqual(E.isValveOpen({type:'valve', isOpen:false}), false);
    assert.strictEqual(E.isValveOpen({type:'valve', isOpen:true}), true);
    assert.strictEqual(E.isValveOpen({type:'junction'}), true);
  });

  test('getCurrentValue respects poisoning window', () => {
    const comp = { waterLevel: 5, poisonedReadings: { waterLevel: { value: 9, startTime: 10, endTime: 20 } } };
    assert.strictEqual(E.getCurrentValue(comp, 'waterLevel', 5), 5);
    assert.strictEqual(E.getCurrentValue(comp, 'waterLevel', 15), 9);
    assert.strictEqual(E.getCurrentValue(comp, 'waterLevel', 25), 5);
  });

  test('applyTimedControl sets pump power and valve state', () => {
    const net = { components: [ { id:'p1', type:'pump', power:0 }, { id:'v1', type:'valve', isOpen:true, flowRate:1 } ], pipes: [] };
    E.applyTimedControl(net, { componentId:'p1', actionType:'set_pump_power', params:{power:'80'} });
    assert.strictEqual(net.components[0].power, 80);
    E.applyTimedControl(net, { componentId:'v1', actionType:'set_valve_state', params:{state:'closed'} });
    assert.strictEqual(net.components[1].isOpen, false);
    assert.strictEqual(net.components[1].flowRate, 0);
    // Test new set_valve_flow action
    E.applyTimedControl(net, { componentId:'v1', actionType:'set_valve_flow', params:{flowRate:'2.5'} });
    assert.strictEqual(net.components[1].flowRate, 2.5);
    assert.strictEqual(net.components[1].isOpen, true);
  });

  test('applyAttack dosing clamps pH to [0,14]', () => {
    const net = { components:[ { id:'t1', type:'tank', ph: 13 } ], pipes: [] };
    E.applyAttack(net, { type:'chemical_dosing', componentId:'t1', chemicalType:'base' });
    assert.strictEqual(net.components[0].ph, 14);
    E.applyAttack(net, { type:'chemical_dosing', componentId:'t1', chemicalType:'acid' });
    assert.ok(approxEqual(net.components[0].ph, 12.5));
  });

  test('find source/dest tanks across valves/junctions', () => {
    const comps = [ {id:'t1', type:'tank'}, {id:'j1', type:'junction'}, {id:'v1', type:'valve', isOpen:true}, {id:'t2', type:'tank'} ];
    const pipes = [ {from:'t1', to:'j1'}, {from:'j1', to:'v1'}, {from:'v1', to:'t2'} ];
    const net = { components: comps, pipes };
    assert.strictEqual(E.findDestTank(net, 'j1').id, 't2');
    assert.strictEqual(E.findSourceTank(net, 'j1').id, 't1');
  });

  function makeTiny(){
    return {
      network: {
        components: [
          { id:'src', type:'source' },
          { id:'j', type:'junction' },
          { id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterLevel:0, waterAmount:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
          { id:'p', type:'pump', maxFlowRate:0.5, power:0 },
          { id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterLevel:0, waterAmount:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
        ],
        pipes: [ {id:'a', from:'src', to:'j'}, {id:'b', from:'j', to:'tA'}, {id:'c', from:'tA', to:'p'}, {id:'d', from:'p', to:'tB'} ]
      },
      controlActions: [], conditionalActions: [], attackScenarios: []
    };
  }

  test('source adds 0.1 per second to downstream tank', () => {
    const tiny = makeTiny();
    const out = E.run(tiny.network, tiny.controlActions, tiny.conditionalActions, tiny.attackScenarios, 10, 20, 1);
    const last = out.results[out.results.length-1];
    // Loop includes t=0..10 (11 steps) -> 1.1 total
    assert.ok(approxEqual(last['tA_waterAmount'], 1.1));
  });

  test('pump transfer uses pump power and mixes chemistry', () => {
    // Isolate pump behavior: no source inflow
    const network = {
      components: [
        { id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterLevel:0, waterAmount:2, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p', type:'pump', maxFlowRate:0.5, power:0 },
        { id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterLevel:0, waterAmount:1, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ {id:'c', from:'tA', to:'p'}, {id:'d', from:'p', to:'tB'} ]
    };
    const controlActions = [ {time:0, componentId:'p', actionType:'set_pump_power', params:{power:'100'}} ];
    const out = E.run(network, controlActions, [], [], 0, 20, 1);
    const first = out.results[0];
    assert.ok(approxEqual(first['tA_waterAmount'], 1.5));
    assert.ok(approxEqual(first['tB_waterAmount'], 1.5));
  });

  test('pipe diameter limits gravity outflow from tank', () => {
    // Two identical nets differing only by pipe.diameter
    const netSmall = {
      components: [
        { id:'t1', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'j', type:'junction' },
        { id:'t2', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ { from:'t1', to:'j', diameter:0.1 }, { from:'j', to:'t2', diameter:0.1 } ]
    };
    const netLarge = JSON.parse(JSON.stringify(netSmall));
    netLarge.pipes[0].diameter = 1.0;
    netLarge.pipes[1].diameter = 1.0;

    const outSmall = E.run(netSmall, [], [], [], 0, 20, 1);
    const outLarge = E.run(netLarge, [], [], [], 0, 20, 1);
    const aSmall = outSmall.results[0]['t1_waterAmount'];
    const aLarge = outLarge.results[0]['t1_waterAmount'];
    // With diameter factor, small (0.1) loses 0.002; large (1.0) loses 0.02
    assert.ok(approxEqual(aSmall, 0.998));
    assert.ok(approxEqual(aLarge, 0.98));
    assert.ok(aSmall > aLarge);
  });

  test('pipe diameter limits pump transfer capacity', () => {
    // Two identical pump networks differing only by pipe.diameter
    const baseNet = {
      components: [
        { id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p', type:'pump', maxFlowRate:0.5, power:0 },
        { id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ { from:'tA', to:'p', diameter:0.1 }, { from:'p', to:'tB', diameter:0.1 } ]
    };
    const netSmall = JSON.parse(JSON.stringify(baseNet));
    const netLarge = JSON.parse(JSON.stringify(baseNet));
    netLarge.pipes[0].diameter = 2.0;
    netLarge.pipes[1].diameter = 2.0;

    const controls = [ { time:0, componentId:'p', actionType:'set_pump_power', params:{ power:'100' } } ];
    const outSmall = E.run(netSmall, controls, [], [], 0, 20, 1);
    const outLarge = E.run(netLarge, controls, [], [], 0, 20, 1);
    const aSmall = outSmall.results[0];
    const aLarge = outLarge.results[0];
    // Small diameter (0.1) → flow 0.05; Large (>=1) → baseline flow 0.5
    assert.ok(approxEqual(aSmall['tA_waterAmount'], 1.95));
    assert.ok(approxEqual(aSmall['tB_waterAmount'], 1.05));
    assert.ok(approxEqual(aLarge['tA_waterAmount'], 1.5));
    assert.ok(approxEqual(aLarge['tB_waterAmount'], 1.5));
    assert.ok(aSmall['tA_waterAmount'] > aLarge['tA_waterAmount']);
  });

  test('data poisoning overrides recorded value in window only', () => {
    const tiny = makeTiny();
    tiny.attackScenarios.push({time:0, type:'data_poisoning', componentId:'tA', poisonType:'waterLevel', value:9, duration:5});
    const out = E.run(tiny.network, tiny.controlActions, tiny.conditionalActions, tiny.attackScenarios, 10, 20, 1);
    const rows = out.results;
    assert.strictEqual(rows[0]['tA_waterLevel'], 9);
    assert.strictEqual(rows[5]['tA_waterLevel'], 9);
    assert.notStrictEqual(rows[6]['tA_waterLevel'], 9);
  });

  test('valve closed blocks traversal', () => {
    const net = {
      components: [
        {id:'t1', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterLevel:0, waterAmount:1, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5},
        {id:'v', type:'valve', isOpen:false},
        {id:'t2', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterLevel:0, waterAmount:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}
      ],
      pipes: [ {from:'t1', to:'v'}, {from:'v', to:'t2'} ]
    };
    const st = { network: net, controlActions: [], conditionalActions: [], attackScenarios: [] };
    const out = E.run(st.network, st.controlActions, st.conditionalActions, st.attackScenarios, 10, 20, 1);
    const last = out.results[out.results.length-1];
    assert.ok(approxEqual(last['t1_waterAmount'], 1.0));
  });

  test('startSimulationPure mirrors run()', () => {
    const tiny = makeTiny();
    const a = E.run(tiny.network, tiny.controlActions, tiny.conditionalActions, tiny.attackScenarios, 5, 20, 1);
    const b = E.startSimulationPure({ network: tiny.network, controlActions: tiny.controlActions, conditionalActions: tiny.conditionalActions, attackScenarios: tiny.attackScenarios }, { duration:5, ambientTemp:20, timeStep:1 });
    assert.strictEqual(a.results.length, b.results.length);
    assert.deepStrictEqual(Object.keys(a.results[5]), Object.keys(b.results[5]));
  });

  // --- Cyber-attack scenarios ---
  test('chemical_dosing acid clamps at 0 and base clamps at 14', () => {
    const net = { components:[ { id:'t', type:'tank', ph: 0.2 } ], pipes: [] };
    E.applyAttack(net, { type:'chemical_dosing', componentId:'t', chemicalType:'acid' });
    assert.strictEqual(net.components[0].ph, 0);
    const net2 = { components:[ { id:'t', type:'tank', ph: 13.4 } ], pipes: [] };
    E.applyAttack(net2, { type:'chemical_dosing', componentId:'t', chemicalType:'base' });
    assert.strictEqual(net2.components[0].ph, 14);
  });

  test('chemical_interference clamps O2/BODn/nitrate/CO2 within bounds', () => {
    const t = { id:'t', type:'tank', o2:14, bodn:9.5, nitrate:4.9, co2:9.8 };
    const net = { components:[t], pipes:[] };
    E.applyAttack(net, { type:'chemical_interference', componentId:'t', chemical:'O2', amount: 5 });
    E.applyAttack(net, { type:'chemical_interference', componentId:'t', chemical:'BODn', amount: 2 });
    E.applyAttack(net, { type:'chemical_interference', componentId:'t', chemical:'nitrate', amount: 2 });
    E.applyAttack(net, { type:'chemical_interference', componentId:'t', chemical:'CO2', amount: 2 });
    assert.strictEqual(t.o2, 15);
    assert.strictEqual(t.bodn, 10);
    assert.strictEqual(t.nitrate, 5);
    assert.strictEqual(t.co2, 10);
    // negative clamp
    E.applyAttack(net, { type:'chemical_interference', componentId:'t', chemical:'O2', amount: -20 });
    assert.strictEqual(t.o2, 0);
  });

  test('physical_damage pump_failure prevents future control actions (fixed behavior)', () => {
    const network = {
      components: [
        { id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p', type:'pump', maxFlowRate:0.5, power:0 },
        { id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ {from:'tA', to:'p'}, {from:'p', to:'tB'} ]
    };
    const controlActions = [ {time:0, componentId:'p', actionType:'set_pump_power', params:{power:'100'}}, {time:1, componentId:'p', actionType:'set_pump_power', params:{power:'100'}} ];
    const attacks = [ {time:0, type:'physical_damage', componentId:'p', damageType:'pump_failure'} ];
    const out = E.run(network, controlActions, [], attacks, 2, 20, 1);
    const rows = out.results;
    // No transfer occurs at any time - pump stays failed and stuck
    assert.ok(approxEqual(rows[0]['tA_waterAmount'], 2)); // no transfer at t=0
    assert.ok(approxEqual(rows[1]['tA_waterAmount'], 2)); // no transfer at t=1
    assert.ok(approxEqual(rows[2]['tA_waterAmount'], 2)); // no transfer at t=2
    // Verify pump is marked as stuck
    const pump = out.simNetwork.components.find(c => c.id === 'p');
    assert.strictEqual(pump.stuck, true);
    assert.strictEqual(pump.power, 0);
    assert.strictEqual(pump.efficiency, 0);
  });

  test('physical_damage guards: pump_failure affects only pumps, valve_stuck only valves', () => {
    const net = { components:[ {id:'t', type:'tank', waterAmount:1, waterLevel:0, shape:'cylindrical', radius:1, maxLevel:10, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'v', type:'valve', isOpen:true}, {id:'p', type:'pump', power:100, maxFlowRate:0.5} ], pipes:[] };
    // Applying pump_failure to valve should do nothing
    E.applyAttack(net, { type:'physical_damage', componentId:'v', damageType:'pump_failure' });
    // Applying valve_stuck to pump should do nothing
    E.applyAttack(net, { type:'physical_damage', componentId:'p', damageType:'valve_stuck' });
    // Correctly applied
    E.applyAttack(net, { type:'physical_damage', componentId:'p', damageType:'pump_failure' });
    E.applyAttack(net, { type:'physical_damage', componentId:'v', damageType:'valve_stuck' });
    const v = net.components.find(c=>c.id==='v');
    const p = net.components.find(c=>c.id==='p');
    assert.strictEqual(v.isOpen, false);
    assert.strictEqual(p.power, 0);
  });

  test('data_poisoning recording respects start and end time window', () => {
    // Ensure well-formed tank geometry to avoid NaN in waterLevel updates
    const r = 1; const area = Math.PI * r * r; // set waterAmount so waterLevel=1 initially
    const net = { components:[ {id:'t', type:'tank', shape:'cylindrical', radius:r, maxLevel:10, waterAmount: area, waterLevel: 0, temperature: 10 } ], pipes:[] };
    const attacks = [ { time:5, type:'data_poisoning', componentId:'t', poisonType:'waterLevel', value: 7, duration: 2 } ];
    const out = E.run(net, [], [], attacks, 10, 20, 1);
    const rows = out.results;
    assert.strictEqual(rows[4]['t_waterLevel'], 1); // before start
    assert.strictEqual(rows[5]['t_waterLevel'], 7); // at start
    assert.strictEqual(rows[7]['t_waterLevel'], 7); // at end
    assert.strictEqual(rows[8]['t_waterLevel'], 1); // after end
  });

  test('physical_damage valve_stuck blocks gravity flow from that tick onward', () => {
    const network = {
      components: [
        { id:'t1', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'v', type:'valve', isOpen:true },
        { id:'j', type:'junction' }
      ],
      pipes: [ {from:'t1', to:'v'}, {from:'v', to:'j'} ]
    };
    // Without attack, at t=0 gravity should remove 0.02 from t1
    let out = E.run(network, [], [], [], 0, 20, 1);
    const first = out.results[0];
    assert.ok(approxEqual(first['t1_waterAmount'], 0.98));
    // With attack at t=0, no gravity depletion at t=0
    const network2 = JSON.parse(JSON.stringify(network));
    out = E.run(network2, [], [], [ {time:0, type:'physical_damage', componentId:'v', damageType:'valve_stuck'} ], 0, 20, 1);
    const first2 = out.results[0];
    assert.ok(approxEqual(first2['t1_waterAmount'], 1.0));
  });

  test('physical_damage leak reduces waterAmount by 5% at attack tick', () => {
    const network = { components: [ {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:10, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 } ], pipes: [] };
    const out = E.run(network, [], [], [ {time:0, type:'physical_damage', componentId:'t', damageType:'leak'} ], 0, 20, 1);
    const first = out.results[0];
    assert.ok(approxEqual(first['t_waterAmount'], 9.5));
  });

  test('poisoning triggers conditional rule in same tick (attacks then rules)', () => {
    const network = {
      components: [
        { id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p', type:'pump', maxFlowRate:0.5, power:0 },
        { id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ {from:'tA', to:'p'}, {from:'p', to:'tB'} ]
    };
    const rules = [ { source:{ componentId:'tA', value:'waterLevel' }, condition:{ operator:'>', threshold: 8 }, target:{ componentId:'p', actionType:'set_pump_power', params:{ power:'100' } } } ];
    const attacks = [ { time:0, type:'data_poisoning', componentId:'tA', poisonType:'waterLevel', value: 9, duration: 1 } ];
    const out = E.run(network, [], rules, attacks, 0, 20, 1);
    const first = out.results[0];
    // Pump should have transferred 0.5 at t=0 due to rule triggered by poisoned value
    assert.ok(approxEqual(first['tA_waterAmount'], 1.5));
    assert.ok(approxEqual(first['tB_waterAmount'], 1.5));
  });

  test('overlapping poisoning on multiple keys only affects targeted keys', () => {
    const network = { components:[ {id:'t', type:'tank', waterLevel: 1, temperature: 10 } ], pipes:[] };
    const attacks = [
      { time:0, type:'data_poisoning', componentId:'t', poisonType:'waterLevel', value: 7, duration: 5 },
      { time:0, type:'data_poisoning', componentId:'t', poisonType:'temperature', value: 50, duration: 5 }
    ];
    const out = E.run(network, [], [], attacks, 0, 20, 1);
    const first = out.results[0];
    assert.strictEqual(first['t_waterLevel'], 7);
    assert.strictEqual(first['t_temperature'], 50);
  });

  test('multi-attack timeline sequencing on pH', () => {
    const network = { components:[ {id:'t', type:'tank', ph: 7 } ], pipes:[] };
    const attacks = [ {time:0, type:'chemical_dosing', componentId:'t', chemicalType:'acid'}, {time:1, type:'chemical_dosing', componentId:'t', chemicalType:'base'} ];
    const out = E.run(network, [], [], attacks, 1, 20, 1);
    const rows = out.results;
    assert.ok(approxEqual(rows[0]['t_ph'], 5.5));
    assert.ok(approxEqual(rows[1]['t_ph'], 7.0));
  });

  // Mass balance with pump-only network
  test('mass balance conserved with pump-only transfers', () => {
    const network = {
      components: [
        { id:'t1', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p', type:'pump', maxFlowRate:0.5, power:0 },
        { id:'t2', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ {from:'t1', to:'p'}, {from:'p', to:'t2'} ]
    };
    const controls = [ {time:0, componentId:'p', actionType:'set_pump_power', params:{power:'100'}}, {time:1, componentId:'p', actionType:'set_pump_power', params:{power:'100'}}, {time:2, componentId:'p', actionType:'set_pump_power', params:{power:'100'}}, {time:3, componentId:'p', actionType:'set_pump_power', params:{power:'100'}} ];
    const out = E.run(network, controls, [], [], 3, 20, 1);
    const last = out.results[out.results.length-1];
    const sum = last['t1_waterAmount'] + last['t2_waterAmount'];
    assert.ok(approxEqual(sum, 2.0));
  });

  // Source/Sink net change
  test('source+sink net change equals +0.05 per tick', () => {
    const network = {
      components: [ {id:'src', type:'source'}, {id:'j', type:'junction'}, { id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }, {id:'sink', type:'sink'} ],
      pipes: [ {from:'src', to:'j'}, {from:'j', to:'t'}, {from:'t', to:'sink'} ]
    };
    const out = E.run(network, [], [], [], 10, 20, 1);
    const last = out.results[out.results.length-1];
    // 11 ticks * (0.1 - 0.05) = 0.55
    assert.ok(approxEqual(last['t_waterAmount'], 0.55));
  });

  // Conditional cascade across pumps (two ticks)
  test('conditional cascade across pumps over two ticks', () => {
    const net = {
      components: [
        { id:'t1', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p1', type:'pump', maxFlowRate:0.5, power:0 },
        { id:'t2', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p2', type:'pump', maxFlowRate:0.5, power:0 },
        { id:'t3', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ {from:'t1', to:'p1'}, {from:'p1', to:'t2'}, {from:'t2', to:'p2'}, {from:'p2', to:'t3'} ]
    };
    const rules = [
      { source:{componentId:'t1', value:'waterAmount'}, condition:{operator:'>', threshold: 0}, target:{componentId:'p1', actionType:'set_pump_power', params:{power:'100'}} },
      { source:{componentId:'t2', value:'waterAmount'}, condition:{operator:'>', threshold: 0}, target:{componentId:'p2', actionType:'set_pump_power', params:{power:'100'}} }
    ];
    const out = E.run(net, [], rules, [], 1, 20, 1);
    const rows = out.results;
    // t=0 moves 0.5 from t1->t2; p2 idle at t=0; at t=1 both pumps active, so t2 receives 0.5 from p1 and sends 0.5 to t3 → t2 remains 0.5
    assert.ok(approxEqual(rows[0]['t1_waterAmount'], 0.5));
    assert.ok(approxEqual(rows[0]['t2_waterAmount'], 0.5));
    assert.ok(approxEqual(rows[1]['t2_waterAmount'], 0.5));
    assert.ok(approxEqual(rows[1]['t3_waterAmount'], 0.5));
  });

  // Max level capping under sustained inflow
  test('waterLevel capped at maxLevel with sustained inflow', () => {
    const net = { components:[ {id:'src', type:'source'}, {id:'j', type:'junction'}, {id:'t', type:'tank', shape:'cylindrical', radius:0.1, maxLevel:0.2, waterAmount:0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5} ], pipes:[ {from:'src', to:'j'}, {from:'j', to:'t'} ] };
    const out = E.run(net, [], [], [], 200, 20, 1);
    const last = out.results[out.results.length-1];
    assert.ok(last['t_waterLevel'] <= 0.2 + 1e-9);
  });

  // Rectangular vs cylindrical area conversion
  test('rectangular tank waterLevel = waterAmount/(width*height)', () => {
    const width = 2, height = 3; const area = width*height;
    const t = { id:'tr', type:'tank', shape:'rectangular', width, height, maxLevel:100, waterAmount:6, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 };
    const net = { components:[ t ], pipes:[] };
    const out = E.run(net, [], [], [], 0, 20, 1);
    const first = out.results[0];
    assert.ok(approxEqual(first['tr_waterLevel'], 6/area));
  });

  // Cylindrical area conversion
  test('cylindrical tank waterLevel = waterAmount/(pi*r^2)', () => {
    const r = 1; const amount = Math.PI * r * r; // waterLevel should be 1
    const t = { id:'tc', type:'tank', shape:'cylindrical', radius:r, maxLevel:100, waterAmount:amount, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 };
    const net = { components:[ t ], pipes:[] };
    const out = E.run(net, [], [], [], 0, 20, 1);
    const first = out.results[0];
    assert.ok(approxEqual(first['tc_waterLevel'], 1));
  });

  // Temperature convergence scales with timeStep
  test('temperature relaxation scales with timeStep', () => {
    const baseTank = { id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1, waterLevel:0, temperature:10, ph:7, o2:8, bodn:2, nitrate:1, co2:5 };
    const net1 = { components:[ JSON.parse(JSON.stringify(baseTank)) ], pipes:[] };
    const net10 = { components:[ JSON.parse(JSON.stringify(baseTank)) ], pipes:[] };
    const out1 = E.run(net1, [], [], [], 0, 20, 1); // Δt=1
    const out10 = E.run(net10, [], [], [], 0, 20, 10); // Δt=10
    const t1 = out1.results[0]['t_temperature']; // 10 + (20-10)*0.001*1 = 10.01
    const t10 = out10.results[0]['t_temperature']; // 10 + (20-10)*0.001*10 = 10.1
    assert.ok(approxEqual(t1, 10.01));
    assert.ok(approxEqual(t10, 10.1));
  });

  // TimeStep scaling for gravity outflow
  test('gravity outflow scales with timeStep', () => {
    const net = {
      components: [ {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'j', type:'junction'} ],
      pipes: [ {from:'t', to:'j'} ]
    };
    const out = E.run(net, [], [], [], 0, 20, 5); // Δt=5
    const first = out.results[0];
    // 0.02 * 5 = 0.1 removed
    assert.ok(approxEqual(first['t_waterAmount'], 0.9));
  });

  // Source inflow diameter & timeStep scaling
  test('source inflow scales with diameter and timeStep', () => {
    const net = {
      components: [ {id:'src', type:'source'}, {id:'j', type:'junction'}, {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5} ],
      pipes: [ {from:'src', to:'j', diameter:0.5}, {from:'j', to:'t'} ]
    };
    const out = E.run(net, [], [], [], 0, 20, 2); // Q = 0.1 * 0.5 * 2 = 0.1
    const first = out.results[0];
    assert.ok(approxEqual(first['t_waterAmount'], 0.1));
  });

  // Sink outflow diameter & timeStep scaling
  test('sink outflow scales with diameter and timeStep', () => {
    const net = {
      components: [ {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'sink', type:'sink'} ],
      pipes: [ {from:'t', to:'sink', diameter:0.5} ]
    };
    const out = E.run(net, [], [], [], 0, 20, 4); // Q = 0.05 * 0.5 * 4 = 0.1
    const first = out.results[0];
    assert.ok(approxEqual(first['t_waterAmount'], 0.9));
  });

  // Valve open gravity with diameter
  test('valve open allows gravity scaled by diameter', () => {
    const net = {
      components: [ {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'v', type:'valve', isOpen:true} ],
      pipes: [ {from:'t', to:'v', diameter:0.5} ]
    };
    const out = E.run(net, [], [], [], 0, 20, 1); // Q = 0.02 * 0.5 = 0.01
    const first = out.results[0];
    assert.ok(approxEqual(first['t_waterAmount'], 0.99));
  });

  // Pump power scaling at 50%
  test('pump transfer scales with power percentage (50%)', () => {
    const net = {
      components: [ {id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'p', type:'pump', maxFlowRate:0.5, power:0}, {id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5} ],
      pipes: [ {from:'tA', to:'p'}, {from:'p', to:'tB'} ]
    };
    const controls = [ {time:0, componentId:'p', actionType:'set_pump_power', params:{power:'50'}} ];
    const out = E.run(net, controls, [], [], 0, 20, 1); // Q = 0.25
    const first = out.results[0];
    assert.ok(approxEqual(first['tA_waterAmount'], 1.75));
    assert.ok(approxEqual(first['tB_waterAmount'], 1.25));
  });

  test('pump power clamped to 0-100% range', () => {
    const net = { components: [ { id:'p', type:'pump', power:50 } ], pipes: [] };
    // Test values > 100% get clamped
    E.applyTimedControl(net, { componentId:'p', actionType:'set_pump_power', params:{power:'150'} });
    assert.strictEqual(net.components[0].power, 100);
    // Test negative values get clamped  
    E.applyTimedControl(net, { componentId:'p', actionType:'set_pump_power', params:{power:'-25'} });
    assert.strictEqual(net.components[0].power, 0);
  });

  test('pump efficiency reduces flow rate proportionally', () => {
    // Two identical pump networks differing only by efficiency
    const baseNet = {
      components: [ {id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'p', type:'pump', maxFlowRate:0.5, power:0, efficiency:0.8}, {id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5} ],
      pipes: [ {from:'tA', to:'p'}, {from:'p', to:'tB'} ]
    };
    const controls = [ {time:0, componentId:'p', actionType:'set_pump_power', params:{power:'100'}} ];
    const out = E.run(baseNet, controls, [], [], 0, 20, 1);
    const first = out.results[0];
    // Flow should be 0.5 * 0.8 = 0.4
    assert.ok(approxEqual(first['tA_waterAmount'], 1.6));
    assert.ok(approxEqual(first['tB_waterAmount'], 1.4));
  });

  // Pump chemistry mixing (pH)
  test('pump mixing computes weighted average for pH', () => {
    const net = {
      components: [ {id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2.0, waterLevel:0, temperature:20, ph:10, o2:8, bodn:2, nitrate:1, co2:5}, {id:'p', type:'pump', maxFlowRate:0.5, power:0}, {id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:4, o2:8, bodn:2, nitrate:1, co2:5} ],
      pipes: [ {from:'tA', to:'p'}, {from:'p', to:'tB'} ]
    };
    const controls = [ {time:0, componentId:'p', actionType:'set_pump_power', params:{power:'100'}} ]; // Q=0.5
    const out = E.run(net, controls, [], [], 0, 20, 1);
    const first = out.results[0];
    // New tB pH = (4*1 + 10*0.5) / 1.5 = 6
    assert.ok(approxEqual(first['tB_ph'], 6));
  });

  // Guard: insufficient volume prevents subtraction
  test('no negative waterAmount: insufficient volume prevents gravity subtraction', () => {
    const net = { components:[ {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0.01, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'j', type:'junction'} ], pipes:[ {from:'t', to:'j'} ] };
    const out = E.run(net, [], [], [], 0, 20, 1);
    const first = out.results[0];
    assert.ok(approxEqual(first['t_waterAmount'], 0.01));
  });

  // Diameter clamping to [0,1]
  test('diameter clamp: >1 treated as 1, <0 treated as 0', () => {
    // Source inflow with diameter 2 behaves like 1
    const netHigh = { components:[ {id:'src', type:'source'}, {id:'j', type:'junction'}, {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5} ], pipes:[ {from:'src', to:'j', diameter:2}, {from:'j', to:'t'} ] };
    const outHigh = E.run(netHigh, [], [], [], 0, 20, 1);
    assert.ok(approxEqual(outHigh.results[0]['t_waterAmount'], 0.1));
    // Gravity with diameter -1 behaves like 0
    const netLow = { components:[ {id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'j', type:'junction'} ], pipes:[ {from:'t', to:'j', diameter:-1} ] };
    const outLow = E.run(netLow, [], [], [], 0, 20, 1);
    assert.ok(approxEqual(outLow.results[0]['t_waterAmount'], 1.0));
  });

  // --- Advanced hydraulics: Hazen–Williams style optional flows ---
  test('HW pipe flow between two tanks respects head difference and K,n', () => {
    const r = 1; const area = Math.PI * r * r;
    const t1 = { id:'t1', type:'tank', shape:'cylindrical', radius:r, maxLevel:100, waterAmount:2*area, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 };
    const t2 = { id:'t2', type:'tank', shape:'cylindrical', radius:r, maxLevel:100, waterAmount:area, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 };
    const net = { components:[ t1, t2 ], pipes:[ {from:'t1', to:'t2', hw:{ K:1, n:2 }} ] };
    // Initially, levels are computed after step, so we need a preliminary step to set head
    const out0 = E.run(net, [], [], [], 0, 20, 1);
    const lvl1 = out0.results[0]['t1_waterLevel'];
    const lvl2 = out0.results[0]['t2_waterLevel'];
    // Next tick: HW flow uses dH = lvl1 - lvl2, q = (dH/K)^(1/n)
    const out1 = E.run(net, [], [], [], 1, 20, 1);
    const rows = out1.results;
    // We expect t1 to decrease and t2 to increase by the same amount
    assert.ok(rows[1]['t1_waterAmount'] < rows[0]['t1_waterAmount']);
    assert.ok(approxEqual(rows[1]['t1_waterAmount'] + rows[1]['t2_waterAmount'], rows[0]['t1_waterAmount'] + rows[0]['t2_waterAmount']));
  });

  test('Pump head-limited flow is min(capacity, head-based limit)', () => {
    const r = 1; const area = Math.PI * r * r;
    const net = {
      components: [
        { id:'tA', type:'tank', shape:'cylindrical', radius:r, maxLevel:100, waterAmount:2*area, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'p', type:'pump', maxFlowRate:1.0, power:100, headGain:0.05 },
        { id:'tB', type:'tank', shape:'cylindrical', radius:r, maxLevel:100, waterAmount:1*area, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 }
      ],
      pipes: [ {from:'tA', to:'p', hw:{K:2,n:2}}, {from:'p', to:'tB', hw:{K:2,n:2}} ]
    };
    // First step establishes levels, second applies head-limited flow
    const out = E.run(net, [], [], [], 1, 20, 1);
    const rows = out.results;
    assert.ok(rows[1]['tA_waterAmount'] < rows[0]['tA_waterAmount']);
  });

  // --- Water quality kinetics: first-order decay ---
  test('first-order decay in tanks reduces species per exp(-k dt)', () => {
    const t = { id:'t', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1, waterLevel:0, temperature:20, ph:7, o2:10, bodn:5, nitrate:2, co2:8, decayRates:{ o2: 0.1, bodn: 0.2 } };
    const net = { components:[ t ], pipes:[] };
    const out = E.run(net, [], [], [], 0, 20, 10); // dt=10
    const first = out.results[0];
    assert.ok(approxEqual(first['t_o2'], 10 * Math.exp(-0.1*10)));
    assert.ok(approxEqual(first['t_bodn'], 5 * Math.exp(-0.2*10)));
  });

  // --- Additional cyber-attack behavior tests derived from paper ---
  test('poisoned reading gets cleared after end time (duration-based effect)', () => {
    const r = 1; const area = Math.PI * r * r; // waterLevel=1 baseline
    const net = { components:[ {id:'t', type:'tank', shape:'cylindrical', radius:r, maxLevel:10, waterAmount: area, waterLevel: 0, temperature: 10 } ], pipes:[] };
    const attacks = [ { time:0, type:'data_poisoning', componentId:'t', poisonType:'waterLevel', value: 9, duration: 1 } ];
    const out = E.run(net, [], [], attacks, 2, 20, 1); // t=0..2, endTime=1
    // Recording shows poisoned values at t=0 and t=1, then clears at t=2
    assert.strictEqual(out.results[0]['t_waterLevel'], 9);
    assert.strictEqual(out.results[1]['t_waterLevel'], 9);
    assert.strictEqual(out.results[2]['t_waterLevel'], 1);
    // The engine should remove expired poisoning entries after t > endTime
    const comp = out.simNetwork.components.find(c => c.id==='t');
    assert.ok(!comp.poisonedReadings || comp.poisonedReadings.waterLevel === undefined);
  });

  test('data_poisoning masks physical changes in recording for targeted key', () => {
    // Chemical dosing changes actual pH; poisoning makes recorded pH show the injected value
    const net = { components:[ {id:'t', type:'tank', ph: 7 } ], pipes:[] };
    const attacks = [
      { time:0, type:'chemical_dosing', componentId:'t', chemicalType:'acid' },
      { time:0, type:'data_poisoning', componentId:'t', poisonType:'ph', value: 9, duration: 1 }
    ];
    const out = E.run(net, [], [], attacks, 0, 20, 1);
    const first = out.results[0];
    // Recorded pH reflects poisoning value, not the physically altered value
    assert.strictEqual(first['t_ph'], 9);
    // Underlying physical state was changed by dosing (7 -> 5.5), which remains in simNetwork state
    assert.ok(Math.abs(out.simNetwork.components.find(c=>c.id==='t').ph - 5.5) < 1e-9);
  });

  test('valve_stuck at t=0 prevents pressure_relief rule from working (fixed behavior)', () => {
    // Engine now properly sets a persistent "stuck" flag; rules cannot override
    const network = {
      components: [
        { id:'t1', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1.0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5 },
        { id:'v', type:'valve', isOpen:true },
        { id:'j', type:'junction' }
      ],
      pipes: [ {from:'t1', to:'v'}, {from:'v', to:'j'} ]
    };
    const rules = [ { source:{componentId:'t1', value:'waterAmount'}, condition:{operator:'>', threshold: 0}, target:{componentId:'v', actionType:'pressure_relief', params:{}} } ];
    // Attack closes valve at t=0 and sets stuck=true; rule cannot reopen it
    const attacks = [ { time:0, type:'physical_damage', componentId:'v', damageType:'valve_stuck' } ];
    const out = E.run(network, [], rules, attacks, 1, 20, 1); // t=0..1
    const rows = out.results;
    // Valve stays stuck - no water outflow occurs at t=1
    assert.ok(approxEqual(rows[1]['t1_waterAmount'], rows[0]['t1_waterAmount']));
    // Verify valve component is marked as stuck
    const valve = out.simNetwork.components.find(c => c.id === 'v');
    assert.strictEqual(valve.stuck, true);
  });

  test('chemical_interference negative amount clamps nitrate to lower bound 0', () => {
    const t = { id:'t', type:'tank', nitrate: 0.2 };
    const net = { components:[t], pipes:[] };
    E.applyAttack(net, { type:'chemical_interference', componentId:'t', chemical:'nitrate', amount: -5 });
    assert.strictEqual(t.nitrate, 0);
  });

  // Deep traversal via many junctions
  test('pump traversal through multiple junctions and valves', () => {
    const comps = [ {id:'tA', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:2, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5}, {id:'j1', type:'junction'}, {id:'v1', type:'valve', isOpen:true}, {id:'j2', type:'junction'}, {id:'p', type:'pump', maxFlowRate:0.5, power:0}, {id:'j3', type:'junction'}, {id:'tB', type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:0, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5} ];
    const pipes = [ {from:'tA', to:'j1'}, {from:'j1', to:'v1'}, {from:'v1', to:'j2'}, {from:'j2', to:'p'}, {from:'p', to:'j3'}, {from:'j3', to:'tB'} ];
    const net = { components: comps, pipes };
    const controls = [ {time:0, componentId:'p', actionType:'set_pump_power', params:{power:'100'}} ];
    const out = E.run(net, controls, [], [], 1, 20, 1);
    const rows = out.results;
    // t=0 applies transfer then gravity flow (-0.02); tA = 2 - 0.5 - 0.02 = 1.48
    assert.ok(approxEqual(rows[0]['tA_waterAmount'], 1.48));
    assert.ok(approxEqual(rows[0]['tB_waterAmount'], 0.5));
  });

  // Poisoning overlap precedence at the same tick uses last applied
  test('overlapping poisoning at same tick applies last assignment', () => {
    const net = { components:[ {id:'t', type:'tank', waterLevel: 1 } ], pipes:[] };
    const attacks = [ {time:5, type:'data_poisoning', componentId:'t', poisonType:'waterLevel', value: 7, duration: 5 }, {time:5, type:'data_poisoning', componentId:'t', poisonType:'waterLevel', value: 3, duration: 5 } ];
    const out = E.run(net, [], [], attacks, 10, 20, 1);
    const rows = out.results;
    // both at t=5; second overrides
    assert.strictEqual(rows[5]['t_waterLevel'], 3);
  });

  // Performance smoke  (small)
  test('performance smoke (50 ticks, 30 comps)', () => {
    const comps = [];
    for (let i=0;i<15;i++) comps.push({id:`t${i}`, type:'tank', shape:'cylindrical', radius:1, maxLevel:10, waterAmount:1, waterLevel:0, temperature:20, ph:7, o2:8, bodn:2, nitrate:1, co2:5});
    for (let i=0;i<5;i++) comps.push({id:`p${i}`, type:'pump', maxFlowRate:0.5, power:0});
    for (let i=0;i<10;i++) comps.push({id:`j${i}`, type:'junction'});
    const pipes = [];
    // chain t0->p0->t1->p1->t2 ...
    pipes.push({from:'t0', to:'p0'});
    for (let i=0;i<4;i++){ pipes.push({from:`p${i}`, to:`t${i+1}`}); if (i+1<4) { pipes.push({from:`t${i+1}`, to:`p${i+1}`}); } }
    const net = { components: comps, pipes };
    const controls = [ {time:0, componentId:'p0', actionType:'set_pump_power', params:{power:'100'}} ];
    const out = E.run(net, controls, [], [], 50, 20, 1);
    assert.strictEqual(out.results.length, 51);
  });

  console.log(`\nSummary: ${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

main().catch(e => { console.error(e); process.exit(1); });
