// ACWA Engine: pure simulation logic for unit testing and reuse
(function(){
  function deepCopy(obj){ return JSON.parse(JSON.stringify(obj)); }

  function isValveOpen(comp){ return comp.type !== 'valve' || comp.isOpen !== false; }

  function nextOutgoingFrom(simNetwork, componentId){ return simNetwork.pipes.find(p => p.from === componentId); }
  function nextIncomingTo(simNetwork, componentId){ return simNetwork.pipes.find(p => p.to === componentId); }

  function findSourceTank(simNetwork, startComponentId){
    let current = simNetwork.components.find(c => c.id === startComponentId);
    const visited = new Set();
    while (current && !visited.has(current.id)){
      visited.add(current.id);
      if (current.type === 'tank') return current;
      if (current.type === 'junction' || (current.type === 'valve' && isValveOpen(current))){
        const incomingPipe = simNetwork.pipes.find(p => p.to === current.id);
        if (!incomingPipe) break;
        current = simNetwork.components.find(c => c.id === incomingPipe.from);
      } else {
        break;
      }
    }
    return null;
  }

  function findDestTank(simNetwork, startComponentId){
    let current = simNetwork.components.find(c => c.id === startComponentId);
    const visited = new Set();
    while (current && !visited.has(current.id)){
      visited.add(current.id);
      if (current.type === 'tank') return current;
      if (current.type === 'junction' || (current.type === 'valve' && isValveOpen(current))){
        const outgoingPipe = simNetwork.pipes.find(p => p.from === current.id);
        if (!outgoingPipe) break;
        current = simNetwork.components.find(c => c.id === outgoingPipe.to);
      } else {
        break;
      }
    }
    return null;
  }

  function applyTimedControl(simNetwork, action){
    const comp = simNetwork.components.find(c => c.id === action.componentId);
    if (!comp || comp.stuck) return; // Stuck components cannot be controlled
    if (action.actionType === 'set_pump_power') {
      const powerValue = parseFloat(action.params.power);
      comp.power = Math.max(0, Math.min(100, powerValue)); // Clamp to 0-100%
    }
    if (action.actionType === 'set_valve_state'){
      const desired = String(action.params.state || '').toLowerCase();
      comp.isOpen = desired === 'open';
      if (!comp.isOpen) comp.flowRate = 0;
    }
    if (action.actionType === 'set_valve_flow'){
      // Set valve flow rate (for flow control valves)
      comp.flowRate = parseFloat(action.params.flowRate || 0);
      comp.isOpen = comp.flowRate > 0;
    }
  }

  function applyAttack(simNetwork, attack){
    const comp = simNetwork.components.find(c => c.id === attack.componentId);
    if (!comp) return;
    switch (attack.type){
      case 'chemical_dosing':
        if (attack.chemicalType === 'acid') comp.ph -= 1.5;
        if (attack.chemicalType === 'base') comp.ph += 1.5;
        comp.ph = Math.max(0, Math.min(14, comp.ph));
        break;
      case 'chemical_interference':
        if (attack.chemical === 'O2') comp.o2 += attack.amount;
        if (attack.chemical === 'BODn') comp.bodn += attack.amount;
        if (attack.chemical === 'nitrate') comp.nitrate += attack.amount;
        if (attack.chemical === 'CO2') comp.co2 += attack.amount;
        comp.o2 = Math.max(0, Math.min(15, comp.o2));
        comp.bodn = Math.max(0, Math.min(10, comp.bodn));
        comp.nitrate = Math.max(0, Math.min(5, comp.nitrate));
        comp.co2 = Math.max(0, Math.min(10, comp.co2));
        break;
      case 'physical_damage':
        if (attack.damageType === 'pump_failure' && comp.type === 'pump'){ 
          comp.power = 0; 
          comp.efficiency = 0; 
          comp.stuck = true; // Prevent future control until manual reset
        }
        if (attack.damageType === 'valve_stuck' && comp.type === 'valve'){ 
          comp.isOpen = false; 
          comp.flowRate = 0; 
          comp.stuck = true; // Prevent future control until manual reset
        }
        if (attack.damageType === 'leak' && comp.type === 'tank'){ 
          comp.waterAmount *= 0.95; 
          comp.stuck = true; // Mark tank as damaged
        }
        break;
      case 'data_poisoning':
        if (!comp.poisonedReadings) comp.poisonedReadings = {};
        comp.poisonedReadings[attack.poisonType] = {
          value: attack.value,
          startTime: attack.time,
          endTime: attack.time + attack.duration
        };
        break;
    }
  }

  function getCurrentValue(sourceComp, key, t){
    let v = sourceComp[key];
    if (sourceComp.poisonedReadings && sourceComp.poisonedReadings[key] !== undefined){
      const p = sourceComp.poisonedReadings[key];
      if ((p.startTime === undefined || t >= p.startTime) && (p.endTime === undefined || t <= p.endTime)) v = p.value;
    }
    return v;
  }

  function applyConditionalActions(simNetwork, rules, t){
    rules.forEach(rule => {
      const sourceComp = simNetwork.components.find(c => c.id === rule.source.componentId);
      if (!sourceComp) return;
      const currentValue = getCurrentValue(sourceComp, rule.source.value, t);
      let ok = false;
      switch (rule.condition.operator){
        case '>': ok = currentValue > rule.condition.threshold; break;
        case '<': ok = currentValue < rule.condition.threshold; break;
        case '==': ok = currentValue == rule.condition.threshold; break;
      }
      if (!ok) return;
      const targetComp = simNetwork.components.find(c => c.id === rule.target.componentId);
      if (!targetComp || targetComp.stuck) return;
      const params = rule.target.params || {};
      switch (rule.target.actionType){
        case 'set_pump_power': 
          const powerValue = parseFloat(params.power);
          targetComp.power = Math.max(0, Math.min(100, powerValue)); // Clamp to 0-100%
          break;
        case 'emergency_stop': targetComp.power = 0; break;
        case 'emergency_close': targetComp.isOpen = false; break;
        case 'pressure_relief': targetComp.isOpen = true; break;
        case 'reduce_power': 
          const reduceAmount = parseFloat(params.power || 50);
          targetComp.power = Math.max(0, targetComp.power - reduceAmount); 
          break;
        case 'increase_power': 
          const increaseAmount = parseFloat(params.power || 100);
          targetComp.power = Math.min(100, targetComp.power + increaseAmount); 
          break;
        case 'set_valve_flow':
          // Flow control for valves in conditional actions
          targetComp.flowRate = parseFloat(params.flowRate || 0);
          targetComp.isOpen = targetComp.flowRate > 0;
          break;
      }
    });
  }

  function clearExpiredPoisoning(simNetwork, t){
    simNetwork.components.forEach(comp => {
      if (!comp.poisonedReadings) return;
      Object.keys(comp.poisonedReadings).forEach(k => {
        const p = comp.poisonedReadings[k];
        if (p.endTime && t > p.endTime){ delete comp.poisonedReadings[k]; }
      });
    });
  }

  function applyPumpTransfers(simNetwork, timeStep){
    simNetwork.components.filter(c => c.type === 'pump').forEach(pump => {
      if (pump.power <= 0) return;
      const inPipe = nextIncomingTo(simNetwork, pump.id);
      const outPipe = nextOutgoingFrom(simNetwork, pump.id);
      if (!inPipe || !outPipe) return;
      const sourceTank = findSourceTank(simNetwork, inPipe.from);
      const destTank = findDestTank(simNetwork, outPipe.to);
      if (!sourceTank || !destTank) return;
      // Diameter factor limits (but does not increase beyond baseline). Default diameter=1.
      const getDiaFactor = (pipe) => {
        const d = (pipe && typeof pipe.diameter === 'number') ? pipe.diameter : 1;
        return Math.max(0, Math.min(1, d));
      };
      const capacityLimit = Math.min(getDiaFactor(inPipe), getDiaFactor(outPipe));
      // Base capacity (without head constraints)
      const efficiency = (pump.efficiency !== undefined) ? Math.max(0, Math.min(1, pump.efficiency)) : 1.0;
      let flowAmount = (pump.power / 100) * pump.maxFlowRate * timeStep * capacityLimit * efficiency;
      // Optional head-limited flow (Hazen-Williams style): pump.headGain and pipe.hw {K,n}
      const hwIn = inPipe.hw;
      const hwOut = outPipe.hw;
      if (pump.headGain !== undefined && hwIn && hwOut){
        const nIn = hwIn.n !== undefined ? hwIn.n : 1.852;
        const nOut = hwOut.n !== undefined ? hwOut.n : 1.852;
        const n = (Math.abs(nIn - nOut) < 1e-12) ? nIn : 1.852;
        const K_in = hwIn.K !== undefined ? hwIn.K : 0;
        const K_out = hwOut.K !== undefined ? hwOut.K : 0;
        const K_total = K_in + K_out;
        const sourceHead = sourceTank.waterLevel || 0;
        const destHead = destTank.waterLevel || 0;
        const headForLoss = pump.headGain + (sourceHead - destHead);
        if (headForLoss <= 0){
          flowAmount = 0;
        } else if (K_total > 0){
          const q_hw = Math.pow(headForLoss / K_total, 1 / n) * timeStep; // convert rate→amount over step
          flowAmount = Math.min(flowAmount, q_hw);
        }
      }
      if (sourceTank.waterAmount < flowAmount) return;
      const totalAmountInDest = destTank.waterAmount + flowAmount;
      if (totalAmountInDest > 0){
        ['temperature','ph','o2','bodn','nitrate','co2'].forEach(param => {
          const weightedAvg = ((destTank[param] * destTank.waterAmount) + (sourceTank[param] * flowAmount)) / totalAmountInDest;
          destTank[param] = weightedAvg;
        });
      }
      sourceTank.waterAmount -= flowAmount;
      destTank.waterAmount += flowAmount;
    });
  }

  // Optional Hazen-Williams style gravity flow between two tanks on a pipe
  function applyHWFlows(simNetwork, timeStep){
    (simNetwork.pipes || []).forEach(pipe => {
      const cfg = pipe.hw;
      if (!cfg) return;
      const fromComp = simNetwork.components.find(c => c.id === pipe.from);
      const toComp = simNetwork.components.find(c => c.id === pipe.to);
      if (!fromComp || !toComp) return;
      if (fromComp.type !== 'tank' || toComp.type !== 'tank') return;
      const K = cfg.K !== undefined ? cfg.K : 0;
      const n = cfg.n !== undefined ? cfg.n : 1.852;
      if (K <= 0) return;
      const headFrom = fromComp.waterLevel || 0;
      const headTo = toComp.waterLevel || 0;
      const dH = headFrom - headTo;
      if (dH <= 0) return; // only forward if upstream head > downstream head
      const q_rate = Math.pow(dH / K, 1 / n); // flow rate per second (units abstract)
      const q_amt = q_rate * timeStep;
      const flowAmount = Math.min(q_amt, fromComp.waterAmount);
      if (flowAmount <= 0) return;
      fromComp.waterAmount -= flowAmount;
      toComp.waterAmount += flowAmount;
    });
  }

  function applyNaturalFlows(simNetwork, timeStep){
    simNetwork.pipes.forEach(pipe => {
      const fromComp = simNetwork.components.find(c => c.id === pipe.from);
      const toComp = simNetwork.components.find(c => c.id === pipe.to);
      if (!fromComp || !toComp) return;
      // Diameter factor limits natural flow along this pipe. Default diameter=1.
      const d = (pipe && typeof pipe.diameter === 'number') ? pipe.diameter : 1;
      const diaFactor = Math.max(0, Math.min(1, d));
      if (fromComp.type === 'source' && (toComp.type === 'junction' || (toComp.type === 'valve' && isValveOpen(toComp)))){
        const flowAmount = 0.1 * timeStep * diaFactor;
        let destTank = findDestTank(simNetwork, toComp.id);
        if (destTank) destTank.waterAmount += flowAmount;
      }
      if (fromComp.type === 'tank' && toComp.type === 'sink'){
        const flowAmount = 0.05 * timeStep * diaFactor;
        if (fromComp.waterAmount >= flowAmount) fromComp.waterAmount -= flowAmount;
      }
      if (fromComp.type === 'tank' && (toComp.type === 'junction' || (toComp.type === 'valve' && isValveOpen(toComp)))){
        const flowAmount = 0.02 * timeStep * diaFactor;
        if (fromComp.waterAmount >= flowAmount) fromComp.waterAmount -= flowAmount;
      }
    });
  }

  function updateTanks(simNetwork, ambientTemp, timeStep){
    simNetwork.components.filter(c => c.type === 'tank').forEach(tank => {
      let area;
      if (tank.shape === 'rectangular') area = tank.width * tank.height; else area = Math.PI * tank.radius * tank.radius;
      tank.waterAmount = Math.max(0, tank.waterAmount);
      tank.waterLevel = tank.waterAmount / area;
      tank.waterLevel = Math.min(tank.waterLevel, tank.maxLevel);
      const tempDiff = ambientTemp - tank.temperature;
      tank.temperature += tempDiff * 0.001 * timeStep;
    });
  }

  // Optional first-order decay kinetics in tanks: C <- C * exp(-k * dt) for configured species
  function applyTankKinetics(simNetwork, timeStep){
    const expf = (k, dt) => Math.exp(-Math.max(0, k) * dt);
    simNetwork.components.filter(c => c.type === 'tank').forEach(tank => {
      const rates = tank.decayRates;
      if (!rates) return;
      ['o2','bodn','nitrate','co2'].forEach(param => {
        if (rates[param] !== undefined && typeof tank[param] === 'number'){
          tank[param] = tank[param] * expf(rates[param], timeStep);
        }
      });
      // Clamp to physical bounds after decay
      if (typeof tank.o2 === 'number') tank.o2 = Math.max(0, Math.min(15, tank.o2));
      if (typeof tank.bodn === 'number') tank.bodn = Math.max(0, Math.min(10, tank.bodn));
      if (typeof tank.nitrate === 'number') tank.nitrate = Math.max(0, Math.min(5, tank.nitrate));
      if (typeof tank.co2 === 'number') tank.co2 = Math.max(0, Math.min(10, tank.co2));
    });
  }

  function recordStep(simNetwork, t){
    const step = { time: t };
    simNetwork.components.forEach(comp => {
      Object.keys(comp).forEach(key => {
        if (typeof comp[key] !== 'number') return;
        let value = comp[key];
        if (comp.poisonedReadings && comp.poisonedReadings[key] !== undefined){
          const p = comp.poisonedReadings[key];
          if ((p.startTime === undefined || t >= p.startTime) && (p.endTime === undefined || t <= p.endTime)) value = p.value;
        }
        step[`${comp.id}_${key}`] = value;
      });
    });
    return step;
  }

  function step(simNetwork, t, ctx){
    const { timeStep, ambientTemp, controlsAtT, attacksAtT, rules } = ctx;
    (controlsAtT || []).forEach(a => applyTimedControl(simNetwork, a));
    (attacksAtT || []).forEach(a => applyAttack(simNetwork, a));
    applyConditionalActions(simNetwork, rules || [], t);
    clearExpiredPoisoning(simNetwork, t);
    applyPumpTransfers(simNetwork, timeStep);
    applyHWFlows(simNetwork, timeStep);
    applyNaturalFlows(simNetwork, timeStep);
    updateTanks(simNetwork, ambientTemp, timeStep);
    applyTankKinetics(simNetwork, timeStep);
    return recordStep(simNetwork, t);
  }

  function run(network, controlActions, conditionalActions, attackScenarios, duration, ambientTemp, timeStep){
    const simNetwork = deepCopy(network);
    const results = [];
    for (let t = 0; t <= duration; t += timeStep){
      const controlsAtT = (controlActions || []).filter(a => a.time === t);
      const attacksAtT = (attackScenarios || []).filter(a => a.time === t);
      const rec = step(simNetwork, t, { timeStep, ambientTemp, controlsAtT, attacksAtT, rules: conditionalActions || [] });
      results.push(rec);
    }
    return { simNetwork, results };
  }

  function startSimulationPure(state, settings){
    const { network, controlActions, conditionalActions, attackScenarios } = state;
    const { duration, ambientTemp, timeStep } = settings;
    return run(network, controlActions, conditionalActions, attackScenarios, duration, ambientTemp, timeStep);
  }

  window.ACWAEngine = {
    isValveOpen,
    findSourceTank,
    findDestTank,
    applyTimedControl,
    applyAttack,
    getCurrentValue,
    applyConditionalActions,
    clearExpiredPoisoning,
    applyPumpTransfers,
    applyNaturalFlows,
    updateTanks,
    recordStep,
    step,
    run,
    startSimulationPure
  };
})();
